/* canvas.js - Functionality moved to main.js */

// This file is kept for structure but logic is now in main.js
// to better handle multiple canvas instances and state.
